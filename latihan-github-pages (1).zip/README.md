# Latihan Pemrograman Web (Versi GitHub Pages)

Proyek ini berisi kumpulan latihan dasar yang dikonversi ke format statis (**HTML, CSS Bootstrap 5, dan JavaScript**) agar dapat langsung dijalankan secara online menggunakan **GitHub Pages**.

## Daftar Halaman
1. `index.html` — Halaman navigasi utama.
2. `kalkulator.html` — Kalkulator dua angka dengan penanganan pembagian nol.
3. `mahasiswa_array.html` — Menampilkan daftar array mahasiswa dan rata-rata nilai.
4. `konversi_nilai.html` — Konversi angka nilai ke huruf berdasarkan skala RPS.
5. `mahasiswa_storage.html` — Form tambah mahasiswa menggunakan `localStorage` browser sebagai pengganti database statis.

## Cara Deploy ke GitHub Pages
1. Ekstrak seluruh isi file ZIP ini ke dalam repository GitHub Anda.
2. Masuk ke **Settings** > **Pages**.
3. Pilih **Branch: main** dan folder **/ (root)**, lalu klik **Save**.
